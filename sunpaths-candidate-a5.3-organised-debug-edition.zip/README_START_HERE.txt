SUNPATHS Candidate A.5.3 — Organised Debug Edition

GitHub Pages deployment:
1. Replace the previous deployed contents with every file in this package.
2. Preserve the app/, docs/ and tests/ folders.
3. Enable GitHub Pages for the repository root.
4. Open index.html through the GitHub Pages URL.

No npm, build command or external runtime is required. React is stored locally
inside app/vendor/.

Start here:
- index.html         playable game
- selftest.html      browser-accessible health check
- docs/FILE_MAP.md   which file controls each feature
- docs/DEBUGGING_GUIDE.md
- docs/ARCHITECTURE.md
- docs/GAME_STATE_REFERENCE.md

The game rules and deterministic output are unchanged from Candidate A.5.2.
The source was consolidated and ordered; Knowledge Link remains removed and
the human-to-AI Summit deadlock fix remains active.
