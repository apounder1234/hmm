// @ts-nocheck
import { defaultConfig, validateConfig } from "../app/config.js";
import { createGame, applyCommand, currentPlayerId, serializeGame, deserializeGame } from "../app/engine.js";
import { pumpAi } from "../app/ai.js";
import { runAutomatedGame } from "../app/simulation.js";
import { invariantErrors, getEffectiveUpgradeCost, getTechnology, validateStartingResourceTotals } from "../app/rules.js";
import { getPublicSummitState } from "../app/trade.js";
import { effectiveBuildCost } from "../app/viewModel.js";
const results = [];
function test(name, fn) {
    try {
        fn();
        results.push({ name, passed: true });
    }
    catch (error) {
        results.push({ name, passed: false, message: error?.message || String(error) });
    }
}
function assert(value, message) { if (!value)
    throw new Error(message); }
function equal(a, b, message) { if (JSON.stringify(a) !== JSON.stringify(b))
    throw new Error(message); }
export function runSelfTests() {
    results.length = 0;
    test("Configuration validates", () => equal(validateConfig(defaultConfig), [], "Configuration errors found."));
    test("Starting totals validate", () => equal(validateStartingResourceTotals(defaultConfig), [], "Starting resource totals are invalid."));
    test("Every Warehouse starts with six resources", () => {
        for (const continent of defaultConfig.continents)
            assert(Object.values(continent.startingWarehouse).reduce((a, b) => a + b, 0) === 6, continent.name);
    });
    test("Every continent has 35 reserve resources", () => {
        for (const continent of defaultConfig.continents)
            assert(Object.values(continent.printedResources).reduce((a, b) => a + b, 0) === 35, continent.name);
    });
    test("Only North America has eight Fuel", () => {
        const eight = defaultConfig.continents.filter(c => c.printedResources.fossilFuel === 8).map(c => c.id);
        equal(eight, ["northAmerica"], "Fuel reserve rule failed.");
    });
    test("Knowledge Link is absent", () => assert(!JSON.stringify(defaultConfig).toLowerCase().includes("knowledgelink"), "Knowledge Link remains."));
    const players = [
        { id: "p1", name: "Human", continentId: "africa", controller: { kind: "human" } },
        { id: "p2", name: "AI Europe", continentId: "europe", controller: { kind: "ai", strategy: "windGrid", difficulty: "standard" } }
    ];
    const game = createGame(defaultConfig, players, "SELFTEST-SUMMIT", { openingMode: "energySummit" });
    applyCommand(game, { type: "selectPrepared", playerId: "p1", pathwayId: "solar", capabilityId: "storage" });
    applyCommand(game, { type: "selectPrepared", playerId: "p2", pathwayId: "wind", capabilityId: "transport" });
    test("Secret choices stay out of public Summit state", () => {
        const publicState = getPublicSummitState(game, "p1");
        const text = JSON.stringify(publicState);
        assert(!text.includes('"wind"'), "Opponent pathway leaked.");
    });
    test("Human-to-AI Summit offer resolves", () => {
        pumpAi(game);
        if (game.opening.summit.pendingOffer)
            applyCommand(game, { type: "respondSummitTrade", recipientId: "p1", accept: false });
        assert(currentPlayerId(game) === "p1", "Human turn not reached.");
        applyCommand(game, { type: "proposeSummitTrade", proposerId: "p1", recipientId: "p2", proposerGives: { criticalMaterials: 1 }, recipientGives: { constructionMaterials: 1 } });
        pumpAi(game);
        assert(game.opening.summit.pendingOffer === null, "Offer stayed pending.");
    });
    test("Unknown action cannot consume an action", () => {
        const before = game.players.p1.actionsRemaining;
        let failed = false;
        try {
            applyCommand(game, { type: "knowledgeLinkBuild", borrowerId: "p1" });
        }
        catch {
            failed = true;
        }
        assert(failed && game.players.p1.actionsRemaining === before, "Invalid command changed state.");
    });
    test("Save and load preserve state", () => {
        const restored = deserializeGame(serializeGame(game));
        equal(restored, game, "Save/load mismatch.");
    });
    test("UI and engine use the same build cost", () => {
        const player = game.players.p1;
        const tech = getTechnology(game, "basicSolar");
        const engineCost = getEffectiveUpgradeCost(game, player.id, tech);
        const uiCost = effectiveBuildCost(game, player, tech);
        assert(engineCost.final.constructionMaterials === uiCost.constructionMaterials, "Other Material cost differs.");
        assert(engineCost.final.criticalMaterials === uiCost.criticalMaterials, "Critical Material cost differs.");
    });
    test("Seeded games are reproducible", () => {
        const a = runAutomatedGame(defaultConfig, "SELFTEST-REPLAY", undefined, false, undefined, 0, { openingMode: "energySummit" });
        const b = runAutomatedGame(defaultConfig, "SELFTEST-REPLAY", undefined, false, undefined, 0, { openingMode: "energySummit" });
        equal(a, b, "Same seed produced different states.");
    });
    test("Complete Summit games finish", () => {
        for (let i = 0; i < 12; i++) {
            const finished = runAutomatedGame(defaultConfig, `SELF-S-${i}`, undefined, false, undefined, i % 6, { openingMode: "energySummit" });
            assert(finished.completed && invariantErrors(finished).length === 0, `Summit game ${i} failed.`);
        }
    });
    test("Complete Starting Plan games finish", () => {
        for (let i = 0; i < 12; i++) {
            const finished = runAutomatedGame(defaultConfig, `SELF-P-${i}`, undefined, false, undefined, i % 6, { openingMode: "startingPlan" });
            assert(finished.completed && invariantErrors(finished).length === 0, `Starting Plan game ${i} failed.`);
        }
    });
    return { passed: results.filter(r => r.passed).length, failed: results.filter(r => !r.passed).length, results: [...results] };
}

