// @ts-nocheck
// SUNPATHS organised source. Each section has one named responsibility.
import { configHash, validateConfig, hashText, defaultConfig } from "./config.js";
import { createRandomState, shuffle } from "./random.js";
import { conditionApplies, getCondition, countInstalled, emptyEnergy, getPlayer, getTechnology, log, resourceTypes, applyCompletedUpgradeConsequences, getEffectiveUpgradeCost, getKnowledgeRequirement, emptyMetrics, getStartingTechnologyIds, setSummitForecast, addEnergy, effectivePathwayOpportunity, fuelPlantMaximumOutput, hasTechnology, pathways, totalEnergy, getContinentGenerationModifiers, getTransmissionLevel, discardCurrentConditions, drawLocalConditions, finalRanking, advanceWeather, setInitialCurrent, setInitialForecast, assertInvariants } from "./rules.js";
import { beginEnergySummit, currentSummitPlayerId, executeDirectTrade, passSummitTurn, proposeSummitTrade, respondSummitTrade } from "./trade.js";
// -----------------------------------------------------------------------------
// Undo and Generation reset
// -----------------------------------------------------------------------------
export function snapshotState(state) { const copy = structuredClone(state); copy.undo = { stack: [], generationStart: null, lockReason: null }; return JSON.stringify(copy); }
export function pushUndo(state) {
    state.undo.stack.push(snapshotState(state));
    if (state.undo.stack.length > 40)
        state.undo.stack.shift();
}
export function setGenerationStartSnapshot(state) { state.undo.generationStart = snapshotState(state); state.undo.stack = []; state.undo.lockReason = null; }
function restore(state, json, stack, generationStart) { const restored = JSON.parse(json); restored.undo = { stack, generationStart, lockReason: null }; Object.assign(state, restored); }
export function undoLast(state) {
    if (state.phase !== "generation.development")
        throw new Error("Undo is only available during Development.");
    const json = state.undo.stack.at(-1);
    if (!json)
        throw new Error("Nothing is available to undo.");
    restore(state, json, state.undo.stack.slice(0, -1), state.undo.generationStart);
}
export function resetGeneration(state) {
    if (state.phase !== "generation.development")
        throw new Error("Generation reset is only available during Development.");
    if (!state.undo.generationStart)
        throw new Error("No Generation-start snapshot is available.");
    restore(state, state.undo.generationStart, [], state.undo.generationStart);
}
export function lockUndo(state, reason) { state.undo.stack = []; state.undo.lockReason = reason; }
// -----------------------------------------------------------------------------
// Development actions and Founding Projects
// -----------------------------------------------------------------------------
function spendAction(player) {
    if (player.actionsRemaining <= 0)
        throw new Error(`${player.name} has no Development actions remaining.`);
    player.actionsRemaining--;
}
function checkWarehouseRoom(state, player, r, amount = 1) {
    if (player.resources[r].warehouse + amount > state.config.rules.warehouseMaximum)
        throw new Error(`${player.name}'s ${r} Warehouse would exceed capacity.`);
}
function consumePayment(player, payment) {
    let total = 0;
    for (const r of resourceTypes) {
        const n = payment[r] ?? 0;
        if (!Number.isInteger(n) || n < 0)
            throw new Error("Import payments must be non-negative integers.");
        if (player.resources[r].warehouse < n)
            throw new Error(`Insufficient ${r} for import.`);
        total += n;
    }
    for (const r of resourceTypes)
        player.resources[r].warehouse -= payment[r] ?? 0;
    return total;
}
function availableForBuild(state, technology) { return technology.alwaysAvailable || state.innovationMarket.visible.includes(technology.id); }
function refillMarket(state) {
    while (state.innovationMarket.visible.length < state.config.rules.innovationMarketSlots && state.innovationMarket.drawPile.length) {
        state.innovationMarket.visible.push(state.innovationMarket.drawPile.shift());
    }
}
function logContinentBuildEffects(state, player, tech, cost) {
    if (cost.usesInnovationBoost) {
        player.currentMetrics.continentAbilityActivations++;
        log(state, "continent.ability", `${player.name} used Innovation Boost to count Knowledge one level higher for ${tech.name}.`, player.id, { abilityId: "innovationBoost", technologyId: tech.id, value: 1 });
    }
    if (cost.usesAsiaSolarDiscount)
        log(state, "continent.ability", `${player.name} used Manufacturing Scale: ${tech.name} cost one fewer Other Material.`, player.id, { abilityId: "manufacturingScale", technologyId: tech.id, value: 1 });
    if (cost.usesAdvancedSystems)
        log(state, "continent.ability", `${player.name}'s Advanced Systems readiness lowered the Knowledge requirement for ${tech.name}.`, player.id, { abilityId: "advancedSystems", technologyId: tech.id, value: cost.standardKnowledgeRequired - cost.knowledgeRequired });
    const regionalPenalties = cost.modifiers.filter(item => ["europeImportedInputs", "northAmericaTransmissionPenalty", "australiaTransmissionPenalty"].includes(item.id));
    for (const modifier of regionalPenalties)
        log(state, "continent.penalty", `${player.name} paid ${modifier.label}: one additional ${modifier.resource === "criticalMaterials" ? "Critical Mineral" : "Other Material"}.`, player.id, { penaltyId: modifier.id, technologyId: tech.id, value: 1 });
    if (cost.consumesLockIn)
        log(state, "continent.penalty", `${player.name} paid the additional Other Material caused by Fossil Lock-In.`, player.id, { penaltyId: "fossilLockIn", technologyId: tech.id, value: 1 });
    if (player.lockInTokens === 1 && tech.pathway === "fossil" && tech.tier !== "basic")
        log(state, "continent.penalty", `${player.name} gained one Fossil Lock-In token. The next Level 2 or 3 non-fossil upgrade costs one additional Other Material.`, player.id, { penaltyId: "fossilLockIn", technologyId: tech.id, value: 1 });
}
function build(state, player, technologyId, options = {}) {
    const tech = getTechnology(state, technologyId);
    if (tech.starter && countInstalled(player, tech.id) > 0)
        throw new Error(`${tech.name} is starting infrastructure and cannot be built again.`);
    if (!availableForBuild(state, tech))
        throw new Error(`${tech.name} is not available.`);
    if (tech.copyLimit !== undefined && countInstalled(player, tech.id) >= tech.copyLimit)
        throw new Error(`${tech.name} copy limit reached.`);
    if (tech.prerequisiteTechnologyId && countInstalled(player, tech.prerequisiteTechnologyId) < 1) {
        const prerequisite = getTechnology(state, tech.prerequisiteTechnologyId);
        throw new Error(`${player.name} must build ${prerequisite.name} before ${tech.name}.`);
    }
    if (tech.minimumRegionalOpportunity !== undefined) {
        const continent = state.config.continents.find(item => item.id === player.continentId);
        const regionalOpportunity = continent?.opportunities?.[tech.pathway] ?? 0;
        if (regionalOpportunity < tech.minimumRegionalOpportunity)
            throw new Error(`${tech.name} provides no additional usable ${tech.pathway} output in ${continent?.name ?? "this region"}. Choose another pathway.`);
    }
    const cost = getEffectiveUpgradeCost(state, player.id, tech, { allowPreparedPathway: options.allowPreparedPathway, useContinentAbility: Boolean(options.useContinentAbility) });
    if (cost.invalidAbilityReason)
        throw new Error(cost.invalidAbilityReason);
    if (cost.effectiveKnowledge < cost.knowledgeRequired)
        throw new Error(`${player.name} needs Knowledge ${cost.knowledgeRequired} to build ${tech.name}.`);
    if (player.resources.constructionMaterials.warehouse < cost.final.constructionMaterials || player.resources.criticalMaterials.warehouse < cost.final.criticalMaterials)
        throw new Error(`${player.name} needs ${cost.final.constructionMaterials} Other Materials and ${cost.final.criticalMaterials} Critical Minerals for ${tech.name}.`);
    player.resources.constructionMaterials.warehouse -= cost.final.constructionMaterials;
    player.resources.criticalMaterials.warehouse -= cost.final.criticalMaterials;
    const prerequisiteInstance = tech.prerequisiteTechnologyId ? player.installed.find(item => item.technologyId === tech.prerequisiteTechnologyId) : null;
    const instance = { instanceId: `${player.id}-${tech.id}-${player.installed.length + 1}`, technologyId: tech.id, builtGeneration: state.generation, storageInput: prerequisiteInstance ? structuredClone(prerequisiteInstance.storageInput) : emptyEnergy(), usedThisGeneration: false, firstOperationLossReduction: 0, temporaryCapacityBonus: 0 };
    let useCapability = cost.usesPreparedCapability;
    if (player.prepared.capabilityId === "transformation" && !player.prepared.capabilityUsed && tech.stage === "transformation") {
        instance.firstOperationLossReduction = 1;
        useCapability = true;
    }
    if (player.prepared.capabilityId === "transport" && !player.prepared.capabilityUsed && tech.special === "gridUpgrade") {
        instance.temporaryCapacityBonus = 1;
        useCapability = true;
    }
    if (prerequisiteInstance)
        player.installed = player.installed.filter(item => item.instanceId !== prerequisiteInstance.instanceId);
    player.installed.push(instance);
    player.currentMetrics.technologiesBuilt.push(tech.id);
    if (cost.modifiers.some(item => item.id === "materialsShortage"))
        player.localCondition.triggered = true;
    if (cost.usesPreparedPathway) {
        player.prepared.pathwayUsed = true;
        if (tech.id === "combinedCycle")
            player.prepared.fossilBlueprintAvailable = false;
    }
    if (useCapability)
        player.prepared.capabilityUsed = true;
    applyCompletedUpgradeConsequences(state, player.id, tech, cost);
    logContinentBuildEffects(state, player, tech, cost);
    if (!tech.alwaysAvailable) {
        state.innovationMarket.visible = state.innovationMarket.visible.filter(id => id !== tech.id);
        refillMarket(state);
    }
    log(state, "action.build", `${player.name} ${prerequisiteInstance ? "upgraded to" : "built"} ${tech.name} for ${cost.final.constructionMaterials} Other Materials and ${cost.final.criticalMaterials} Critical Minerals.`, player.id, { technologyId: tech.id, replacedTechnologyId: prerequisiteInstance?.technologyId ?? null, knowledgeRequired: cost.knowledgeRequired, cost: cost.final, modifiers: cost.modifiers });
}
export function foundingProjectDefinition(state, playerId) {
    const player = getPlayer(state, playerId);
    const pathway = state.config.preparedPathways.find(item => item.id === player.prepared.pathwayId);
    if (!pathway)
        throw new Error(`${player.name} has no Starting Pathway.`);
    if (pathway.id === "fossil")
        return { kind: "fuelNetwork", name: pathway.foundingLabel, cost: pathway.foundingCost ?? { constructionMaterials: 2, criticalMaterials: 0 } };
    const technology = getTechnology(state, pathway.foundingTechnologyId);
    const costResult = getEffectiveUpgradeCost(state, player.id, technology, { allowPreparedPathway: false });
    return { kind: "technology", name: technology.name, technology, cost: costResult.final, costResult };
}
export function canCompleteFoundingProject(state, playerId) {
    const player = getPlayer(state, playerId);
    const project = foundingProjectDefinition(state, playerId);
    return player.resources.constructionMaterials.warehouse >= project.cost.constructionMaterials
        && player.resources.criticalMaterials.warehouse >= project.cost.criticalMaterials;
}
export function resolveFoundingProject(state, playerId, complete) {
    if (state.phase !== "setup.foundingProjects")
        throw new Error("Founding Projects are not active.");
    const player = getPlayer(state, playerId);
    if (player.prepared.foundingProjectResolved)
        throw new Error(`${player.name}'s Founding Project is already resolved.`);
    const project = foundingProjectDefinition(state, playerId);
    if (!complete) {
        player.prepared.foundingProjectResolved = true;
        player.prepared.foundingProjectDeferred = true;
        log(state, "founding.deferred", `${player.name} deferred ${project.name}; the Starting Pathway becomes a one-use Blueprint later.`, player.id);
        return;
    }
    if (!canCompleteFoundingProject(state, playerId))
        throw new Error(`${player.name} needs ${project.cost.constructionMaterials} Other Materials and ${project.cost.criticalMaterials} Critical Minerals for ${project.name}.`);
    if (project.kind === "fuelNetwork") {
        player.resources.constructionMaterials.warehouse -= project.cost.constructionMaterials;
        player.resources.criticalMaterials.warehouse -= project.cost.criticalMaterials;
        if (player.resources.fossilFuel.currentContinent > 0 && player.resources.fossilFuel.warehouse < state.config.rules.warehouseMaximum) {
            player.resources.fossilFuel.currentContinent--;
            player.resources.fossilFuel.warehouse++;
        }
        player.prepared.fossilBlueprintAvailable = true;
        player.prepared.pathwayUsed = true;
        log(state, "founding.completed", `${player.name} completed the Fuel Supply Network: 1 Fuel moved into the Warehouse and a Combined-Cycle Blueprint is ready.`, player.id);
    }
    else {
        player.resources.constructionMaterials.warehouse -= project.cost.constructionMaterials;
        player.resources.criticalMaterials.warehouse -= project.cost.criticalMaterials;
        const tech = project.technology;
        const instance = { instanceId: `${player.id}-${tech.id}-${player.installed.length + 1}`, technologyId: tech.id, builtGeneration: 0, storageInput: emptyEnergy(), usedThisGeneration: false, firstOperationLossReduction: 0, temporaryCapacityBonus: 0 };
        player.installed.push(instance);
        if (project.costResult) {
            applyCompletedUpgradeConsequences(state, player.id, tech, project.costResult);
            logContinentBuildEffects(state, player, tech, project.costResult);
        }
        player.prepared.pathwayUsed = true;
        log(state, "founding.completed", `${player.name} completed ${tech.name} before Generation 1 without using a Development action.`, player.id, { technologyId: tech.id });
    }
    player.prepared.foundingProjectResolved = true;
    player.prepared.foundingProjectCompleted = true;
}
export function performDevelopmentAction(state, playerId, action) {
    if (state.phase !== "generation.development")
        throw new Error("Development actions are not allowed in this phase.");
    const player = getPlayer(state, playerId);
    switch (action.kind) {
        case "extract": {
            const account = player.resources[action.resource];
            if (account.currentContinent <= 0)
                throw new Error(`No ${action.resource} remains in continent stock.`);
            checkWarehouseRoom(state, player, action.resource);
            spendAction(player);
            account.currentContinent--;
            account.warehouse++;
            player.currentMetrics.resourcesExtracted[action.resource] = (player.currentMetrics.resourcesExtracted[action.resource] ?? 0) + 1;
            log(state, "action.extract", `${player.name} extracted 1 ${action.resource}.`, player.id);
            break;
        }
        case "harvestBiomass": {
            const account = player.resources.biomass;
            if (account.currentContinent <= 0)
                throw new Error("No Biomass remains to harvest.");
            checkWarehouseRoom(state, player, "biomass");
            spendAction(player);
            account.currentContinent--;
            account.warehouse++;
            player.currentMetrics.resourcesExtracted.biomass = (player.currentMetrics.resourcesExtracted.biomass ?? 0) + 1;
            log(state, "action.harvest", `${player.name} harvested 1 Biomass.`, player.id);
            break;
        }
        case "research": {
            if (player.knowledge >= state.config.rules.knowledgeMaximum)
                throw new Error("Knowledge is already at its maximum.");
            const nextLevel = player.knowledge + 1;
            const printedCost = state.config.knowledge?.advancementCosts?.[nextLevel];
            if (!printedCost)
                throw new Error(`Knowledge ${nextLevel} has no configured learning cost.`);
            let generalCost = printedCost.constructionMaterials;
            const criticalCost = printedCost.criticalMaterials;
            let preparedDiscount = false;
            if (player.prepared.capabilityId === "research" && !player.prepared.capabilityUsed && generalCost > 0) {
                generalCost--;
                preparedDiscount = true;
            }
            const useAppliedLearning = player.appliedLearningTokens > 0 && generalCost > 0;
            if (useAppliedLearning)
                generalCost--;
            if (player.resources.constructionMaterials.warehouse < generalCost || player.resources.criticalMaterials.warehouse < criticalCost)
                throw new Error(`${player.name} needs ${generalCost} Other Materials and ${criticalCost} Critical Minerals to reach Knowledge ${nextLevel}.`);
            spendAction(player);
            player.resources.constructionMaterials.warehouse -= generalCost;
            player.resources.criticalMaterials.warehouse -= criticalCost;
            if (useAppliedLearning) {
                player.appliedLearningTokens--;
                player.currentMetrics.appliedLearningSpent++;
            }
            if (preparedDiscount)
                player.prepared.capabilityUsed = true;
            player.knowledge = nextLevel;
            player.currentMetrics.knowledgeGained++;
            const centre = player.installed.find(i => getTechnology(state, i.technologyId).special === "researchCentre" && !i.usedThisGeneration);
            if (centre) {
                player.temporaryKnowledge++;
                centre.usedThisGeneration = true;
            }
            log(state, "action.research", `${player.name} increased permanent Knowledge to ${player.knowledge} for ${generalCost} Other Materials and ${criticalCost} Critical Minerals${useAppliedLearning ? ", using 1 Applied Learning token" : ""}.`, player.id, { nextLevel, generalCost, criticalCost, appliedLearningUsed: useAppliedLearning });
            break;
        }
        case "build":
            spendAction(player);
            try {
                build(state, player, action.technologyId, { useContinentAbility: Boolean(action.useContinentAbility) });
            }
            catch (error) {
                player.actionsRemaining++;
                throw error;
            }
            break;
        case "publicImport": {
            if (!state.config.trade.publicImportEnabled)
                throw new Error("Public import is disabled.");
            checkWarehouseRoom(state, player, action.receive);
            if ((state.worldMarket?.[action.receive] ?? 0) <= 0)
                throw new Error(`The global ${action.receive} stock is empty.`);
            let required = action.receive === "criticalMaterials" ? state.config.trade.criticalImportCost : state.config.trade.normalImportCost;
            const usePreparedTrade = player.prepared.capabilityId === "trade" && !player.prepared.capabilityUsed;
            if (usePreparedTrade)
                required = Math.max(1, required - 1);
            if ((action.payment[action.receive] ?? 0) > 0)
                throw new Error("The imported resource cannot also be used as payment.");
            const paymentTotal = Object.values(action.payment).reduce((n, v) => n + (v ?? 0), 0);
            if (paymentTotal !== required)
                throw new Error(`Import requires exactly ${required} resources.`);
            spendAction(player);
            try {
                consumePayment(player, action.payment);
            }
            catch (error) {
                player.actionsRemaining++;
                throw error;
            }
            if (usePreparedTrade)
                player.prepared.capabilityUsed = true;
            player.resources[action.receive].warehouse++;
            state.worldMarket[action.receive]--;
            player.currentMetrics.importsCompleted++;
            player.currentMetrics.resourcesImported[action.receive] = (player.currentMetrics.resourcesImported[action.receive] ?? 0) + 1;
            log(state, "action.import", `${player.name} imported 1 ${action.receive} for ${required} resources.`, player.id, { receive: action.receive, payment: structuredClone(action.payment), required });
            break;
        }
        case "adapt": {
            const active = player.localCondition;
            if (!active)
                throw new Error("No Local Condition to adapt to.");
            const def = getCondition(state, active.definitionId);
            if (!("adaptable" in def.effect) || !def.effect.adaptable)
                throw new Error(`${def.name} has no Adapt response.`);
            if (active.adapted)
                throw new Error("Local Condition was already adapted to.");
            spendAction(player);
            active.adapted = true;
            log(state, "action.adapt", `${player.name} adapted to ${def.name}.`, player.id);
            break;
        }
        case "pass":
            spendAction(player);
            log(state, "action.pass", `${player.name} passed.`, player.id);
            break;
    }
}
// -----------------------------------------------------------------------------
// Game-state creation
// -----------------------------------------------------------------------------
function createLocalDeck(config, state) {
    const cards = config.localConditions.flatMap(def => Array.from({ length: def.copies }, (_, i) => ({ cardId: `${def.id}-${i + 1}`, definitionId: def.id })));
    return { drawPile: shuffle(cards, state.streams.conditions), discardPile: [], resetAtGenerationFive: false };
}
function createMarket(config, state) {
    const advanced = shuffle(config.technologies.filter(t => !t.starter && !t.alwaysAvailable).map(t => t.id), state.streams.market);
    return { drawPile: advanced.slice(config.rules.innovationMarketSlots), visible: advanced.slice(0, config.rules.innovationMarketSlots) };
}
function createPlayer(config, setup) {
    const continent = config.continents.find(c => c.id === setup.continentId);
    if (!continent)
        throw new Error(`Unknown continent ${setup.continentId}`);
    const resources = {};
    for (const r of resourceTypes) {
        const printed = continent.printedResources[r];
        const configuredWarehouse = continent.startingWarehouse?.[r];
        const warehouse = configuredWarehouse === undefined ? Math.floor(printed / 4) : configuredWarehouse;
        if (!Number.isInteger(warehouse) || warehouse < 0 || warehouse > printed)
            throw new Error(`${continent.name} has an invalid starting Warehouse value for ${r}.`);
        resources[r] = { printedStarting: printed, currentContinent: printed - warehouse, warehouse };
    }
    const warehouseTotal = resourceTypes.reduce((sum, r) => sum + resources[r].warehouse, 0);
    if (warehouseTotal !== (config.rules.openingWarehouseSize ?? 6))
        throw new Error(`${continent.name} must begin with exactly ${config.rules.openingWarehouseSize ?? 6} ready resources; configured ${warehouseTotal}.`);
    const startingIds = getStartingTechnologyIds({ config }, continent);
    const installed = startingIds.map((technologyId, i) => ({ instanceId: `${setup.id}-${technologyId}-${i + 1}`, technologyId, builtGeneration: 0, storageInput: emptyEnergy(), usedThisGeneration: false, firstOperationLossReduction: 0, temporaryCapacityBonus: 0 }));
    return {
        id: setup.id, name: setup.name, continentId: setup.continentId, controller: setup.controller, resources, knowledge: continent.startingKnowledge, temporaryKnowledge: 0,
        appliedLearningTokens: 0,
        prepared: {
            pathwayId: null, capabilityId: null, pathwayUsed: false, capabilityUsed: false,
            foundingProjectResolved: false, foundingProjectCompleted: false, foundingProjectDeferred: false,
            fossilBlueprintAvailable: false
        },
        summitTrades: 0,
        continentAbilityUsed: false, continentAbilityActivations: 0, firstSolarDiscountUsed: false, lockInTokens: 0,
        installed, localCondition: null, actionsRemaining: 0, completedTrades: 0, initiatedTrades: 0,
        lightByGeneration: {}, reliabilityByGeneration: {}, cumulative: { totalLight: 0, reliableGenerations: 0, demandMetGenerations: 0, systemLoss: { thermal: 0, battery: 0, lighting: 0, other: 0 }, curtailment: 0 }, currentMetrics: emptyMetrics(config.demand.reliabilityTargets[1] ?? 2)
    };
}
export function createGame(config, players, seed, options = {}) {
    const errors = validateConfig(config);
    if (errors.length)
        throw new Error(`Invalid configuration:\n${errors.join("\n")}`);
    if (players.length < 1 || players.length > 6)
        throw new Error("Game requires one to six players.");
    if (new Set(players.map(p => p.continentId)).size !== players.length)
        throw new Error("Continents must be unique.");
    const rng = createRandomState(seed);
    const playerMap = Object.fromEntries(players.map(p => [p.id, createPlayer(config, p)]));
    const openingMode = options.openingMode ?? config.opening?.defaultMode ?? "startingPlan";
    const state = {
        schemaVersion: "1.0.0", engineVersion: "0.12.0-summit-streamlined-knowledge",
        gameId: `game-${configHash(config)}-${seed}-${players.map(p => p.id).join("-")}`,
        config: structuredClone(config), configHash: configHash(config), seed,
        debugMode: options.debugMode ?? false, executionMode: options.executionMode ?? "interactive", rng,
        phase: "setup.preparedSelection", generation: 0, actionRound: 1,
        turnOrder: players.map(p => p.id),
        firstPlayerIndex: options.initialFirstPlayerIndex === undefined ? 0 : Math.max(0, Math.min(players.length - 1, Math.floor(options.initialFirstPlayerIndex))),
        activeTurnIndex: options.initialFirstPlayerIndex === undefined ? 0 : Math.max(0, Math.min(players.length - 1, Math.floor(options.initialFirstPlayerIndex))),
        players: playerMap,
        worldMarket: structuredClone(config.trade.worldMarketStarting ?? { fossilFuel: 6, biomass: 6, constructionMaterials: 6, criticalMaterials: 6 }),
        opening: {
            mode: openingMode,
            revealed: false,
            summit: { round: 0, direction: null, order: [], activeIndex: 0, pendingOffer: null, lastResolution: null, completed: openingMode !== "energySummit" },
            foundingOrder: players.map(p => p.id), foundingIndex: 0
        },
        weather: { currentDie: "A", current: null, forecastDie: "B", forecast: null, history: {} },
        localConditions: createLocalDeck(config, rng), innovationMarket: createMarket(config, rng), log: [], completed: false, results: null,
        undo: { stack: [], generationStart: null, lockReason: null }
    };
    log(state, "game.created", `Created SUNPATHS game with ${players.length} players and seed ${seed}.`, null, { openingMode });
    if (openingMode === "energySummit")
        setSummitForecast(state);
    return state;
}
// -----------------------------------------------------------------------------
// Energy Dispatch and Light resolution
// -----------------------------------------------------------------------------
function operational(state, i) { return i.builtGeneration < state.generation || state.config.rules.buildAndOperateSameGeneration || i.builtGeneration === 0; }
function tableValue(table, input) {
    if (input < 0 || input >= table.length)
        throw new Error(`Input ${input} is outside conversion table.`);
    return table[input];
}
function withdraw(pool, amount) {
    if (amount > totalEnergy(pool))
        throw new Error("Insufficient Energy in pool.");
    const result = emptyEnergy();
    let remaining = amount;
    for (const pathway of pathways) {
        const take = Math.min(pool[pathway], remaining);
        pool[pathway] -= take;
        result[pathway] = take;
        remaining -= take;
        if (remaining === 0)
            break;
    }
    return result;
}
function withdrawSpecified(pool, request) {
    const out = emptyEnergy();
    for (const p of pathways) {
        const n = request[p] ?? 0;
        if (!Number.isInteger(n) || n < 0)
            throw new Error("Energy allocations must be non-negative integers.");
        if (pool[p] < n)
            throw new Error(`Insufficient ${p} Energy for allocation.`);
        pool[p] -= n;
        out[p] = n;
    }
    return out;
}
function selectRecoveryBreakthroughTarget(state, player, targetId) {
    const c = conditionApplies(state, player);
    if (c?.effect.kind !== "storageRecoveryBonus")
        return;
    if (targetId === null) {
        player.localCondition.selectedTechnologyInstanceId = null;
        return;
    }
    const instance = player.installed.find(i => i.instanceId === targetId);
    if (!instance || getTechnology(state, instance.technologyId).storage?.type !== "battery")
        throw new Error("Recovery Breakthrough target must be an installed Battery.");
    player.localCondition.selectedTechnologyInstanceId = targetId;
}
function storageCapacity(_state, _player, _instance, tech) {
    return Math.max(0, tech.storage?.capacity ?? 0);
}
function gridCapacity(state, player) {
    let capacity = 0;
    for (const i of player.installed) {
        if (!operational(state, i))
            continue;
        const t = getTechnology(state, i.technologyId);
        if (t.stage === "transport")
            capacity += t.capacity + i.temporaryCapacityBonus;
    }
    const c = conditionApplies(state, player);
    if (c?.effect.kind === "gridCapacityDelta") {
        const protectedBySmartGrid = c.effect.amount < 0 && hasTechnology(player, "smartGrid");
        if (!protectedBySmartGrid)
            capacity += c.effect.amount;
    }
    return Math.max(0, capacity);
}
function lightingConfig(state, player) {
    if (hasTechnology(player, "efficientLighting"))
        return getTechnology(state, "efficientLighting");
    return getTechnology(state, "standardLighting");
}
function localGenerationDelta(state, player, pathway) {
    const c = conditionApplies(state, player);
    if (pathway === "solar" && c?.effect.kind === "solarDelta")
        return c.effect.amount;
    if (pathway === "wind" && c?.effect.kind === "windDelta")
        return c.effect.amount;
    return 0;
}
function captureOutput(state, player, pathway) {
    const continent = state.config.continents.find(c => c.id === player.continentId);
    const cap = player.installed.filter(i => operational(state, i)).map(i => getTechnology(state, i.technologyId)).filter(t => t.pathway === pathway && t.stage === "capture").reduce((n, t) => n + t.capacity, 0);
    const ideal = Math.min(continent.opportunities[pathway], cap);
    const table = state.config.weather[pathway][state.weather.current];
    const base = tableValue(table, ideal);
    const resilience = pathway === "solar" && hasTechnology(player, "advancedSolar")
        ? 1
        : pathway === "wind" && hasTechnology(player, "advancedWind")
            ? 1
            : 0;
    const continentModifier = getContinentGenerationModifiers(state, player.id, pathway);
    const withoutContinent = Math.max(0, Math.min(ideal, base + resilience + localGenerationDelta(state, player, pathway)));
    const regionalCap = continentModifier.generationBonus > 0 ? continent.opportunities[pathway] : ideal;
    const output = Math.max(0, Math.min(regionalCap, base + resilience + localGenerationDelta(state, player, pathway) + continentModifier.generationBonus));
    const gained = Math.max(0, output - withoutContinent);
    if (gained > 0) {
        player.currentMetrics.continentAbilityValue += gained;
        player.currentMetrics.continentAbilityActivations++;
        log(state, "continent.ability", `${player.name}'s regional ${pathway} ability added ${gained} Energy.`, player.id, { abilityId: continentModifier.abilityId, pathway, value: gained });
    }
    return output;
}
function addHydroInflow(state, player) {
    const reservoirs = player.installed.filter(i => operational(state, i) && getTechnology(state, i.technologyId).storage?.type === "reservoir");
    if (reservoirs.length === 0)
        return;
    const continent = state.config.continents.find(c => c.id === player.continentId);
    let inflow = tableValue(state.config.weather.hydro[state.weather.current], continent.opportunities.hydro);
    if (hasTechnology(player, "advancedHydroTurbine"))
        inflow += 1;
    const c = conditionApplies(state, player);
    if (c?.effect.kind === "hydroDelta")
        inflow = Math.max(0, inflow + c.effect.amount);
    const continentModifier = getContinentGenerationModifiers(state, player.id, "hydro");
    if (continentModifier.hydroDelta !== 0) {
        const before = inflow;
        inflow = Math.max(0, inflow + continentModifier.hydroDelta);
        const value = inflow - before;
        if (value > 0) {
            player.currentMetrics.continentAbilityValue += value;
            player.currentMetrics.continentAbilityActivations++;
            log(state, "continent.ability", `${player.name}'s river-system ability added ${value} Hydro inflow.`, player.id, { abilityId: continentModifier.abilityId, pathway: "hydro", value });
        }
        else if (value < 0) {
            player.currentMetrics.continentPenaltyActivations++;
            log(state, "continent.penalty", `${player.name}'s drought exposure removed ${Math.abs(value)} additional Hydro inflow.`, player.id, { penaltyId: continentModifier.penaltyId, pathway: "hydro", value: Math.abs(value) });
        }
    }
    for (const r of reservoirs) {
        if (inflow <= 0)
            break;
        const tech = getTechnology(state, r.technologyId);
        const room = storageCapacity(state, player, r, tech) - totalEnergy(r.storageInput);
        const add = Math.max(0, Math.min(room, inflow));
        r.storageInput.hydro += add;
        inflow -= add;
    }
}
function dischargeHydro(state, player, requested) {
    const result = emptyEnergy();
    if (requested === 0)
        return result;
    const turbineCapacity = player.installed.filter(i => operational(state, i)).map(i => getTechnology(state, i.technologyId)).filter(t => t.pathway === "hydro" && t.stage === "transformation").reduce((n, t) => n + t.capacity, 0);
    const continent = state.config.continents.find(c => c.id === player.continentId);
    const max = Math.min(turbineCapacity, continent.opportunities.hydro);
    if (requested > max)
        throw new Error(`Hydro request exceeds dispatch limit ${max}.`);
    let remaining = requested;
    for (const r of player.installed.filter(i => operational(state, i) && getTechnology(state, i.technologyId).storage?.type === "reservoir")) {
        const take = Math.min(r.storageInput.hydro, remaining);
        r.storageInput.hydro -= take;
        result.hydro += take;
        remaining -= take;
        if (remaining === 0)
            break;
    }
    if (remaining > 0)
        throw new Error("Insufficient Reservoir Energy for Hydro dispatch.");
    return result;
}
function dischargeBatteries(state, player, requests) {
    const energy = emptyEnergy();
    let loss = 0;
    const discharged = new Set();
    for (const [instanceId, input] of Object.entries(requests)) {
        if (input === 0)
            continue;
        const i = player.installed.find(x => x.instanceId === instanceId);
        if (!i)
            throw new Error(`Unknown storage instance ${instanceId}.`);
        const t = getTechnology(state, i.technologyId);
        if (t.storage?.type !== "battery")
            throw new Error(`${t.name} is not a Battery.`);
        if (!operational(state, i))
            throw new Error(`${t.name} is not operational.`);
        if (input > totalEnergy(i.storageInput))
            throw new Error(`Battery ${instanceId} lacks stored Energy.`);
        let output = tableValue(t.storage.recovery.outputsByInput, input);
        const condition = conditionApplies(state, player);
        if (condition?.effect.kind === "storageRecoveryBonus" && !player.localCondition?.triggered && player.localCondition?.selectedTechnologyInstanceId === instanceId) {
            output = Math.min(input, output + condition.effect.amount);
            player.localCondition.triggered = true;
        }
        const origin = withdraw(i.storageInput, input);
        const recovered = emptyEnergy();
        let remaining = output;
        for (const p of pathways) {
            const share = input === 0 ? 0 : Math.floor(origin[p] * output / input);
            recovered[p] = Math.min(origin[p], share);
            remaining -= recovered[p];
        }
        for (const p of pathways) {
            if (remaining <= 0)
                break;
            const spare = origin[p] - recovered[p];
            const take = Math.min(spare, remaining);
            recovered[p] += take;
            remaining -= take;
        }
        addEnergy(energy, recovered);
        loss += input - output;
        discharged.add(instanceId);
    }
    return { energy, loss, discharged };
}
function operateFuelPlants(state, player, requests) {
    const energy = emptyEnergy();
    let loss = 0;
    const continent = state.config.continents.find(c => c.id === player.continentId);
    const usedByPathway = { biomass: 0, fossil: 0 };
    const opportunityByPathway = { biomass: effectivePathwayOpportunity(state, player, "biomass"), fossil: effectivePathwayOpportunity(state, player, "fossil") };
    let disruptionUsed = false;
    const c = conditionApplies(state, player);
    for (const i of player.installed) {
        const requested = requests[i.instanceId] ?? 0;
        if (requested === 0)
            continue;
        const t = getTechnology(state, i.technologyId);
        if (!t.fuel || !(t.pathway === "biomass" || t.pathway === "fossil"))
            throw new Error(`${t.name} is not a fuel plant.`);
        if (!operational(state, i))
            throw new Error(`${t.name} is not operational.`);
        if (i.usedThisGeneration)
            throw new Error(`${t.name} has already operated.`);
        let output = requested;
        if (c?.effect.kind === "firstFuelPlantOutputDelta" && !disruptionUsed) {
            output = Math.max(0, output + c.effect.amount);
            disruptionUsed = true;
            player.localCondition.triggered = true;
        }
        const maximumOutput = fuelPlantMaximumOutput(state, player, t);
        if (requested < 1 || requested > maximumOutput)
            throw new Error(`${t.name} requested output outside 1-${maximumOutput}.`);
        const pathway = t.pathway;
        const remainingOpportunity = opportunityByPathway[pathway] - usedByPathway[pathway];
        if (output > remainingOpportunity)
            throw new Error(`${pathway} output exceeds Opportunity.`);
        if (player.resources[t.fuel.resource].warehouse < t.fuel.units)
            throw new Error(`${player.name} lacks ${t.fuel.resource}.`);
        player.resources[t.fuel.resource].warehouse -= t.fuel.units;
        player.currentMetrics.fuelConsumed[t.fuel.resource] = (player.currentMetrics.fuelConsumed[t.fuel.resource] ?? 0) + t.fuel.units;
        energy[pathway] += output;
        usedByPathway[pathway] += output;
        i.usedThisGeneration = true;
        const base = t.loss?.fixedPerOperation ?? 0;
        const actual = Math.max(0, base - i.firstOperationLossReduction);
        loss += actual;
        i.firstOperationLossReduction = 0;
    }
    return { energy, loss };
}
function chargeBatteries(state, player, available, charges, discharged) {
    for (const [instanceId, allocation] of Object.entries(charges)) {
        const amount = totalEnergy(allocation);
        if (amount === 0)
            continue;
        const i = player.installed.find(x => x.instanceId === instanceId);
        if (!i)
            throw new Error(`Unknown storage instance ${instanceId}.`);
        const t = getTechnology(state, i.technologyId);
        if (t.storage?.type !== "battery")
            throw new Error(`${t.name} is not a Battery.`);
        if (discharged.has(instanceId) && !state.config.rules.batteryChargeAndDischargeSameGeneration)
            throw new Error("A Battery cannot charge and discharge in the same Generation.");
        const room = storageCapacity(state, player, i, t) - totalEnergy(i.storageInput);
        if (amount > room)
            throw new Error(`${t.name} storage capacity exceeded.`);
        const moved = withdrawSpecified(available, allocation);
        addEnergy(i.storageInput, moved);
    }
}
function biomassRegrowth(state, player) {
    if ((player.currentMetrics.fuelConsumed.biomass ?? 0) <= 0)
        return;
    const systems = player.installed
        .filter(i => operational(state, i.builtGeneration))
        .map(i => getTechnology(state, i.technologyId))
        .filter(t => t.pathway === "biomass" && (t.biomassRegrowth ?? 0) > 0);
    if (systems.length === 0)
        return;
    let amount = Math.max(...systems.map(t => t.biomassRegrowth ?? 0));
    const c = conditionApplies(state, player);
    if (c?.effect.kind === "biomassRegrowthDelta")
        amount = Math.max(0, amount + c.effect.amount);
    if (c?.effect.kind === "biomassRegrowthSet")
        amount = c.effect.value;
    if (c?.effect.kind === "hydroDelta" && !hasTechnology(player, "basicReservoir") && !hasTechnology(player, "advancedReservoir") && !hasTechnology(player, "advancedHydroTurbine") && c.effect.fallbackBiomassRegrowthDelta !== undefined)
        amount = Math.max(0, amount + c.effect.fallbackBiomassRegrowthDelta);
    const account = player.resources.biomass;
    const before = account.currentContinent;
    account.currentContinent = Math.min(account.printedStarting, account.currentContinent + amount);
    const restored = account.currentContinent - before;
    if (restored > 0 && systems.some(t => t.appliedLearning)) {
        const maximum = state.config.rules.appliedLearningTokenMaximum ?? 2;
        const gained = player.appliedLearningTokens < maximum ? 1 : 0;
        player.appliedLearningTokens = Math.min(maximum, player.appliedLearningTokens + gained);
        player.currentMetrics.appliedLearningGained += gained;
        if (gained > 0)
            log(state, "biomass.appliedLearning", `${player.name} gained 1 Applied Learning token by operating and replenishing Biomass.`, player.id);
    }
}
export function resolveDispatch(state, playerId, plan) {
    if (state.phase !== "generation.dispatch")
        throw new Error("Dispatch is not available in this phase.");
    const player = getPlayer(state, playerId);
    selectRecoveryBreakthroughTarget(state, player, plan.recoveryBreakthroughTargetInstanceId);
    const available = emptyEnergy();
    addHydroInflow(state, player);
    const solar = captureOutput(state, player, "solar"), wind = captureOutput(state, player, "wind");
    available.solar += solar;
    available.wind += wind;
    player.currentMetrics.grossEnergy.solar = solar;
    player.currentMetrics.grossEnergy.wind = wind;
    const hydro = dischargeHydro(state, player, plan.hydroOutputRequested);
    addEnergy(available, hydro);
    player.currentMetrics.grossEnergy.hydro = hydro.hydro;
    const battery = dischargeBatteries(state, player, plan.batteryDischargeInput);
    addEnergy(available, battery.energy);
    if (state.config.systemLoss.countBattery)
        player.currentMetrics.systemLoss.battery += battery.loss;
    const fuel = operateFuelPlants(state, player, plan.fuelPlantOutput);
    addEnergy(available, fuel.energy);
    player.currentMetrics.grossEnergy.biomass = fuel.energy.biomass;
    player.currentMetrics.grossEnergy.fossil = fuel.energy.fossil;
    if (state.config.systemLoss.countThermal)
        player.currentMetrics.systemLoss.thermal += fuel.loss;
    chargeBatteries(state, player, available, plan.batteryCharge, battery.discharged);
    const transported = withdrawSpecified(available, plan.transportByPathway);
    const transportedTotal = totalEnergy(transported);
    const capacity = gridCapacity(state, player);
    const solarLeapfrog = getContinentGenerationModifiers(state, player.id, "solar");
    const leapfrogCapacity = solarLeapfrog.transmissionLossIgnored > 0 && transported.solar > 0 ? solarLeapfrog.transmissionLossIgnored : 0;
    if (transportedTotal > capacity + leapfrogCapacity || (transportedTotal > capacity && transported.solar < transportedTotal - capacity))
        throw new Error(`Transport request ${transportedTotal} exceeds usable Grid capacity ${capacity}${leapfrogCapacity ? ` plus ${leapfrogCapacity} Solar Leapfrog` : ""}.`);
    const lighting = lightingConfig(state, player);
    let transmissionLoss = getTransmissionLevel(state, player.id) === 1 && transportedTotal >= 3 ? 1 : 0;
    if (transmissionLoss > 0 && transported.solar > 0 && solarLeapfrog.transmissionLossIgnored > 0) {
        const ignored = Math.min(transmissionLoss, solarLeapfrog.transmissionLossIgnored);
        transmissionLoss -= ignored;
        player.currentMetrics.continentAbilityValue += ignored;
        player.currentMetrics.continentAbilityActivations++;
        log(state, "continent.ability", `${player.name}'s Solar Leapfrog protected ${ignored} Solar Energy from Level 1 transmission loss.`, player.id, { abilityId: solarLeapfrog.abilityId, pathway: "solar", value: ignored });
    }
    player.currentMetrics.systemLoss.other += transmissionLoss;
    let input = Math.min(Math.max(0, transportedTotal - transmissionLoss), lighting.maximumInput);
    let light = tableValue(lighting.conversion.outputsByInput, input);
    let lightMax = state.config.demand.maximumLight;
    const c = conditionApplies(state, player);
    if (c?.effect.kind === "lightMaximumDelta")
        lightMax = Math.max(1, lightMax + c.effect.amount);
    light = Math.min(light, lightMax);
    if (state.config.systemLoss.countLighting)
        player.currentMetrics.systemLoss.lighting += Math.max(0, input - light);
    player.currentMetrics.deliveredLight = light;
    player.lightByGeneration[state.generation] = light;
    let target = state.config.demand.reliabilityTargets[state.generation];
    if (c?.effect.kind === "demandTargetDelta")
        target = Math.max(0, Math.min(state.config.demand.maximumLight, target + c.effect.amount));
    const met = light >= target;
    const pointMaximum = state.config.rules.reliabilityPointMaximum ?? 4;
    const surplus = light > target;
    const pointEarned = surplus && player.cumulative.reliableGenerations < pointMaximum;
    player.currentMetrics.reliabilityTarget = target;
    player.currentMetrics.reliabilityMet = met;
    player.currentMetrics.reliabilityPointEarned = pointEarned;
    player.currentMetrics.reliabilityPointCapped = surplus && !pointEarned;
    player.reliabilityByGeneration[state.generation] = pointEarned;
    player.currentMetrics.curtailed = totalEnergy(available) + Math.max(0, transportedTotal - input);
    player.currentMetrics.storedEnd = player.installed.reduce((n, i) => n + totalEnergy(i.storageInput), 0);
    player.cumulative.totalLight += light;
    if (met)
        player.cumulative.demandMetGenerations = (player.cumulative.demandMetGenerations ?? 0) + 1;
    if (pointEarned)
        player.cumulative.reliableGenerations++;
    player.cumulative.systemLoss.thermal += player.currentMetrics.systemLoss.thermal;
    player.cumulative.systemLoss.battery += player.currentMetrics.systemLoss.battery;
    player.cumulative.systemLoss.lighting += player.currentMetrics.systemLoss.lighting;
    player.cumulative.systemLoss.other += player.currentMetrics.systemLoss.other;
    player.cumulative.curtailment += player.currentMetrics.curtailed;
    biomassRegrowth(state, player);
    log(state, "dispatch.resolved", `${player.name} delivered ${light} Light${pointEarned ? " and earned 1 Reliability Point" : met ? " and met demand" : " but missed demand"}.`, player.id, { metrics: structuredClone(player.currentMetrics) });
}
// -----------------------------------------------------------------------------
// Command state machine and phase progression
// -----------------------------------------------------------------------------
function orderedFromFirst(state) { return [...state.turnOrder.slice(state.firstPlayerIndex), ...state.turnOrder.slice(0, state.firstPlayerIndex)]; }
function activePlayerId(state) { return state.turnOrder[state.activeTurnIndex]; }
function resetPlayerForGeneration(state, p) {
    p.actionsRemaining = state.config.rules.actionsPerGeneration;
    p.completedTrades = 0;
    p.initiatedTrades = 0;
    p.temporaryKnowledge = 0;
    p.currentMetrics = emptyMetrics(state.config.demand.reliabilityTargets[state.generation]);
    for (const i of p.installed) {
        i.usedThisGeneration = false;
        i.temporaryCapacityBonus = 0;
    }
}
function beginGeneration(state) {
    if (state.phase !== "generation.start")
        throw new Error("Generation cannot begin in this phase.");
    if (state.generation === 0)
        state.generation = 1;
    state.weather.history[state.generation] = state.weather.current;
    for (const p of Object.values(state.players))
        resetPlayerForGeneration(state, p);
    state.actionRound = 1;
    state.activeTurnIndex = state.firstPlayerIndex;
    state.phase = "generation.localConditions";
    log(state, "generation.started", `Generation ${state.generation} started.`, null, { current: state.weather.current, forecast: state.weather.forecast });
}
function advanceDevelopmentTurn(state) {
    state.activeTurnIndex = (state.activeTurnIndex + 1) % state.turnOrder.length;
    if (state.activeTurnIndex === state.firstPlayerIndex) {
        if (state.actionRound < state.config.rules.actionsPerGeneration) {
            state.actionRound += 1;
            log(state, "development.round", `Development action round ${state.actionRound} began.`);
        }
        else {
            state.phase = "generation.dispatch";
            state.activeTurnIndex = state.firstPlayerIndex;
            log(state, "development.complete", `Development completed for Generation ${state.generation}.`);
        }
    }
}
function advanceDispatchTurn(state) {
    state.activeTurnIndex = (state.activeTurnIndex + 1) % state.turnOrder.length;
    if (state.activeTurnIndex === state.firstPlayerIndex) {
        state.phase = "generation.review";
        log(state, "generation.review", `Generation ${state.generation} review is ready.`);
    }
}
function finishReview(state) {
    if (state.phase !== "generation.review")
        throw new Error("Review cannot finish in this phase.");
    discardCurrentConditions(state);
    if (state.generation === state.config.rules.generations) {
        state.results = finalRanking(state);
        state.completed = true;
        state.phase = "game.complete";
        log(state, "game.complete", "The game is complete.", null, { results: state.results });
        return;
    }
    state.firstPlayerIndex = (state.firstPlayerIndex + 1) % state.turnOrder.length;
    state.phase = "generation.advanceWeather";
}
function applyCommandMutable(state, command) {
    switch (command.type) {
        case "selectPrepared": {
            if (state.phase !== "setup.preparedSelection")
                throw new Error("Prepared selections are closed.");
            const p = getPlayer(state, command.playerId);
            p.prepared.pathwayId = command.pathwayId;
            p.prepared.capabilityId = command.capabilityId;
            log(state, "prepared.selected", `${p.name} selected hidden Prepared cards.`, p.id);
            if (Object.values(state.players).every(x => x.prepared.pathwayId && x.prepared.capabilityId)) {
                if (state.opening.mode === "energySummit") {
                    if (!state.weather.forecast)
                        setSummitForecast(state);
                    beginEnergySummit(state);
                }
                else
                    state.phase = "setup.revealPrepared";
            }
            break;
        }
        case "rollCurrent":
            setInitialCurrent(state);
            break;
        case "revealPrepared": {
            if (state.phase !== "setup.revealPrepared")
                throw new Error("Starting Plans cannot be revealed now.");
            state.opening.revealed = true;
            state.phase = "setup.foundingProjects";
            state.opening.foundingIndex = 0;
            for (const p of Object.values(state.players))
                log(state, "prepared.revealed", `${p.name}: ${p.prepared.pathwayId} / ${p.prepared.capabilityId}.`, p.id);
            break;
        }
        case "resolveFoundingProject": {
            if (state.phase !== "setup.foundingProjects")
                throw new Error("Founding Projects are not active.");
            const expectedId = state.opening.foundingOrder[state.opening.foundingIndex];
            if (command.playerId !== expectedId)
                throw new Error(`It is ${expectedId}'s Founding Project decision.`);
            resolveFoundingProject(state, command.playerId, command.complete);
            state.opening.foundingIndex++;
            if (state.opening.foundingIndex >= state.opening.foundingOrder.length)
                state.phase = "setup.rollCurrent";
            break;
        }
        case "proposeSummitTrade":
            proposeSummitTrade(state, command.proposerId, command.recipientId, command.proposerGives, command.recipientGives);
            break;
        case "respondSummitTrade":
            respondSummitTrade(state, command.recipientId, command.accept);
            break;
        case "passSummitTurn":
            passSummitTurn(state, command.playerId);
            break;
        case "rollForecast":
            setInitialForecast(state);
            break;
        case "beginGeneration":
            beginGeneration(state);
            break;
        case "drawLocalConditions":
            drawLocalConditions(state);
            break;
        case "developmentAction": {
            if (command.playerId !== activePlayerId(state))
                throw new Error(`It is ${activePlayerId(state)}'s Development turn.`);
            performDevelopmentAction(state, command.playerId, command.action);
            advanceDevelopmentTurn(state);
            break;
        }
        case "directTrade": {
            if (command.aId !== activePlayerId(state))
                throw new Error(`Only the active player may propose a direct trade.`);
            const result = executeDirectTrade(state, command.aId, command.bId, command.aGives, command.bGives);
            if (result.actionSpent)
                advanceDevelopmentTurn(state);
            break;
        }
        case "dispatch": {
            if (state.phase !== "generation.dispatch")
                throw new Error("Dispatch is not active.");
            if (command.playerId !== activePlayerId(state))
                throw new Error(`It is ${activePlayerId(state)}'s Dispatch turn.`);
            resolveDispatch(state, command.playerId, command.plan);
            advanceDispatchTurn(state);
            break;
        }
        case "finishReview":
            finishReview(state);
            break;
        case "advanceWeather":
            advanceWeather(state);
            break;
        case "undo":
        case "resetGeneration": throw new Error("History commands are handled transactionally.");
        default: throw new Error(`Unknown command ${command.type}.`);
    }
}
export function applyCommand(state, command) {
    if (command.type === "undo") {
        undoLast(state);
        return state;
    }
    if (command.type === "resetGeneration") {
        resetGeneration(state);
        return state;
    }
    const draft = structuredClone(state);
    if (command.type === "developmentAction" || command.type === "directTrade")
        pushUndo(draft);
    applyCommandMutable(draft, command);
    if (command.type === "drawLocalConditions" && draft.phase === "generation.development")
        setGenerationStartSnapshot(draft);
    if (draft.phase === "generation.dispatch")
        lockUndo(draft, "Development completed and Dispatch began.");
    Object.assign(state, draft);
    return state;
}
export function applyCommandFast(state, command) {
    if (state.executionMode !== "simulation")
        throw new Error("Fast command execution is reserved for Simulation mode.");
    if (command.type === "undo" || command.type === "resetGeneration")
        throw new Error("History commands are unavailable in Simulation mode.");
    applyCommandMutable(state, command);
    return state;
}
export function currentPlayerId(state) { return state.phase === "generation.development" || state.phase === "generation.dispatch" ? activePlayerId(state) : state.phase === "setup.summit" ? currentSummitPlayerId(state) : state.phase === "setup.foundingProjects" ? state.opening.foundingOrder[state.opening.foundingIndex] ?? null : null; }
export function currentOrder(state) { return orderedFromFirst(state); }
// -----------------------------------------------------------------------------
// Save, load and migration
// -----------------------------------------------------------------------------
export function serializeGame(state) {
    const core = {
        saveFormat: "sunpaths-save",
        saveSchemaVersion: state.schemaVersion,
        engineVersion: state.engineVersion,
        gameId: state.gameId,
        savedAtIso: new Date().toISOString(),
        configHash: state.configHash,
        gameState: state
    };
    const raw = JSON.stringify(core);
    return JSON.stringify({ ...core, checksum: hashText(raw) });
}
function migratePhase3State(input) {
    const state = structuredClone(input);
    state.debugMode ??= false;
    state.executionMode ??= "interactive";
    if (!state.engineVersion || state.engineVersion === "0.3.0")
        state.engineVersion = "0.4.0";
    state.config.rules.reliabilityPointMaximum ??= 4;
    state.config.trade.freeDirectTradesPerGeneration ??= state.config.trade.directTradesPerGeneration ?? 0;
    state.config.rules.appliedLearningTokenMaximum ??= 2;
    state.config.rules.openingWarehouseSize ??= 6;
    state.config.affinityThresholds ??= structuredClone(defaultConfig.affinityThresholds);
    state.config.continents = state.config.continents.map(continent => ({ ...structuredClone(defaultConfig.continents.find(item => item.id === continent.id) ?? {}), ...continent }));
    state.config.trade.worldMarketStarting ??= structuredClone(defaultConfig.trade.worldMarketStarting);
    state.worldMarket ??= structuredClone(state.config.trade.worldMarketStarting);
    state.config.localConditions = state.config.localConditions.map(condition => condition.id === "storageBreakthrough"
        ? { ...condition, id: "recoveryBreakthrough", name: "Recovery Breakthrough" }
        : condition);
    for (const player of Object.values(state.players)) {
        player.initiatedTrades ??= 0;
        player.appliedLearningTokens ??= 0;
        player.continentAbilityUsed ??= false;
        player.continentAbilityActivations ??= 0;
        player.firstSolarDiscountUsed ??= false;
        player.lockInTokens ??= 0;
        player.summitImports ??= {};
        player.summitExports ??= {};
        player.cumulative.demandMetGenerations ??= Object.values(player.lightByGeneration ?? {}).filter((light, index) => {
            const generation = index + 1;
            return light >= (state.config.demand.reliabilityTargets[generation] ?? 0);
        }).length;
        player.cumulative.reliableGenerations = Math.min(player.cumulative.reliableGenerations ?? 0, state.config.rules.reliabilityPointMaximum);
        player.currentMetrics.reliabilityPointEarned ??= false;
        player.currentMetrics.reliabilityPointCapped ??= false;
        player.currentMetrics.appliedLearningGained ??= 0;
        player.currentMetrics.appliedLearningSpent ??= 0;
        player.currentMetrics.resourcesImported ??= {};
        player.currentMetrics.resourcesExported ??= {};
        player.currentMetrics.continentAbilityValue ??= 0;
        player.currentMetrics.continentAbilityActivations ??= 0;
        player.currentMetrics.continentPenaltyActivations ??= 0;
        if (player.localCondition?.definitionId === "storageBreakthrough") {
            player.localCondition.definitionId = "recoveryBreakthrough";
            player.localCondition.cardId = player.localCondition.cardId.replace("storageBreakthrough", "recoveryBreakthrough");
        }
    }
    for (const pile of [state.localConditions.drawPile, state.localConditions.discardPile]) {
        for (const card of pile) {
            if (card.definitionId === "storageBreakthrough")
                card.definitionId = "recoveryBreakthrough";
            card.cardId = card.cardId.replace("storageBreakthrough", "recoveryBreakthrough");
        }
    }
    return state;
}
export function deserializeGame(json) {
    const envelope = JSON.parse(json);
    if (envelope.saveFormat !== "sunpaths-save")
        throw new Error("Not a SUNPATHS save file.");
    if (envelope.saveSchemaVersion !== "1.0.0")
        throw new Error(`Unsupported save schema ${envelope.saveSchemaVersion}.`);
    const { checksum: stored, ...core } = envelope;
    if (hashText(JSON.stringify(core)) !== stored)
        throw new Error("Save checksum mismatch.");
    const migrated = migratePhase3State(envelope.gameState);
    assertInvariants(migrated);
    return migrated;
}

